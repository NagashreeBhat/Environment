package com.example.environmentalchanges.Activities;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.environmentalchanges.R;

public class LoginPage extends AppCompatActivity implements View.OnClickListener{
EditText editUsername,editEmail,editPassword;
Button signup;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_page);
        editUsername = findViewById(R.id.editUserName);
        editEmail = findViewById(R.id.editEmail);
        editPassword = findViewById(R.id.editPassword);
        signup = findViewById(R.id.signup);
        signup.setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {
        switch(view.getId()){
            case R.id.signup:
                Intent signup = new Intent(this, ProfilePage.class);
                signup.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(signup);
                finish();
                break;
        }

    }
}
